﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tester
{
    /// <summary>
    /// Interaction logic for NewTrack.xaml
    /// </summary>
    public partial class NewTrack : Window
    {
        public NewTrack()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void SecondenClick(object sender, RoutedEventArgs e)
        {
            Seconden.Visibility = Visibility.Visible;
            MinutenSeconden.Visibility = Visibility.Hidden;
            UrenMinutenSeconden.Visibility = Visibility.Hidden;
        }
        private void MinutenSecondenClick(object sender, RoutedEventArgs e)
        {
            Seconden.Visibility = Visibility.Hidden;
            MinutenSeconden.Visibility = Visibility.Visible;
            UrenMinutenSeconden.Visibility = Visibility.Hidden;
        }
        private void UrenMinutenSecondenClick(object sender, RoutedEventArgs e)
        {
            Seconden.Visibility = Visibility.Hidden;
            MinutenSeconden.Visibility = Visibility.Hidden;
            UrenMinutenSeconden.Visibility = Visibility.Visible;
        }
    }
}
